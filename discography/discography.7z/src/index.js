import React from 'react'
import ReactDOM from 'react-dom';
import Discography from './Discography'

ReactDOM.render(  <Discography />, document.getElementById('root'));

